//
//  EditProfileVC.swift
//  Speedo Transfer
//
//

import UIKit

class EditProfileVC: UIViewController {

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.style = .editor
        title = "Edit Profile"
    }
    
}
