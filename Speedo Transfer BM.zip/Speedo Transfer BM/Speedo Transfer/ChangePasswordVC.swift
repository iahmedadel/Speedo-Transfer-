//
//  ChangePasswordVC.swift
//  Speedo Transfer
//
//

import UIKit

class ChangePasswordVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.style = .editor
        title = "Change Password"
    }
    
}
