
import UIKit

class PersonalInfoVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationItem.style = .editor
        title = "Profile Information"
    }
    

   

}
