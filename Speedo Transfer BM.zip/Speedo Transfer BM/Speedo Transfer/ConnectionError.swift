//
//  ConnectionError.swift
//  SpeedoTransfer
//
//

import UIKit

class ConnectionError: UIViewController {
    

    @IBOutlet weak var imageMessage: UILabel!
    @IBOutlet weak var connectionImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func callUsBTN(_ sender: UIButton) {
    }
}
